#pragma once
#include <ros/ros.h>
#include <opencv2/highgui/highgui.hpp>

extern int ROW;                            // 图像的height 480
extern int COL;                            // 图像的width 752
const int NUM_OF_CAM = 1;                  // 相机数量


extern std::string IMAGE_TOPIC;            // /imu0
extern std::string IMU_TOPIC;              // /cam0/image_raw
extern std::vector<std::string> CAM_NAMES; // 相机配置文件路径
extern int MAX_CNT;                        // 特征跟踪的最大特征数 150
extern int MIN_DIST;                       // 两特征的最小距离 30
extern int FREQ;                           // 估计结果发布频率 10Hz
extern double F_THRESHOLD;                 // RANSAC阈值（1.0像素)
extern int SHOW_TRACK;                     // 是否发布跟踪图像的topic（1）
extern int EQUALIZE;                       // 是否在图像太暗或者光线不均时找足够特征（1）
extern int FISHEYE;                        // 是否为鱼眼模式（0）


extern int WINDOW_SIZE;                    // 滑动窗口大小（20帧）
extern int STEREO_TRACK;                   // 是否立体跟踪（0）
extern int FOCAL_LENGTH;                   // 焦距
extern bool PUB_THIS_FRAME;                // 定时器，是否输出当前帧（0）

void readParameters(ros::NodeHandle &n);
