#pragma once

#include <cstdio>
#include <iostream>
#include <queue>
#include <execinfo.h>
#include <csignal>

#include <opencv2/opencv.hpp>
#include <eigen3/Eigen/Dense>

#include "camodocal/camera_models/CameraFactory.h"
#include "camodocal/camera_models/CataCamera.h"       //卡塔相机
#include "camodocal/camera_models/PinholeCamera.h"    //针孔相机

#include "parameters.h"
#include "tic_toc.h"

using namespace std;
using namespace camodocal;
using namespace Eigen;

/* 判断点是否在图像边界范围内 */
bool inBorder(const cv::Point2f &pt);

/* 按照status的状态对向量v进行删减，只保留status值为1的数 */
void reduceVector(vector<cv::Point2f> &v, vector<uchar> status);
void reduceVector(vector<int> &v, vector<uchar> status);

class FeatureTracker
{
  public:
    FeatureTracker();                                        //空构造函数

    void readImage(const cv::Mat &_img);                     //读取图像，提取跟踪特征点

    void setMask();                                          //根据掩膜，将特征点进行排序，并保证相邻两特征点距离不大于阈值

    void addPoints();                                        //将图像检测到的新角点添加进frow_pts中，id置-1，track_cnt置1

    bool updateID(unsigned int i);                           //对id进行更新，若ids[i]不存在，返回false，否则返回true，若ids[i]==-1,则设置ids[i]=n_id++;

    void readIntrinsicParameter(const string &calib_file);   // 读取相机参数

    void showUndistortion(const string &name);               //显示未失真图像(未用到）

    void rejectWithF();                                      //2d->2d RANSAC拒绝，删除部分特征点

    vector<cv::Point2f> undistortedPoints();                 //获得所有未失真的角点的归一化相机坐标（z=1)

    cv::Mat mask;                                            //掩膜
    cv::Mat fisheye_mask;                                    //鱼眼掩膜（未用到）

    /* prev,cur,forw三个img和pts,
     * cur和forw分别是LK光流跟踪的前后两帧，forw才是真正的”当前”帧，
     * cur实际上是上一帧，而prev是上一次发布的帧，它实际上是光流跟踪以后，
     * prev和forw根据Fundamental Matrix做RANSAC剔除outlier用的，也就是rejectWithF()函数. */
    cv::Mat prev_img;
    cv::Mat cur_img;                                         //当前图像
    cv::Mat forw_img;
    vector<cv::Point2f> prev_pts;
    vector<cv::Point2f> cur_pts;
    vector<cv::Point2f> forw_pts;

    vector<cv::Point2f> n_pts;                               //检测到的角点
    vector<int> ids;                                         //某特征点的编号
    vector<int> track_cnt;                                   //某特征点被连续跟踪的次数
    camodocal::CameraPtr m_camera;                           //相机信息

    static int n_id;
};
