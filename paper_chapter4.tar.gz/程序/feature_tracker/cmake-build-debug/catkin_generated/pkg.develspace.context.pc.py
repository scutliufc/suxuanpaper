# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "".split(';') if "" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "feature_tracker"
PROJECT_SPACE_DIR = "/home/suxuan/dashgo_ws/src/VINS-Mono/feature_tracker/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
