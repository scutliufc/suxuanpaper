#pragma once

#include <ros/ros.h>
#include <vector>
#include <eigen3/Eigen/Dense>
#include "utility/utility.h"
#include <opencv2/opencv.hpp>
#include <opencv2/core/eigen.hpp>
#include <fstream>

const double FOCAL_LENGTH = 460.0;                  //焦距
const int WINDOW_SIZE = 10;                         //窗口大小
const int NUM_OF_CAM = 1;                           //相机数
const int NUM_OF_F = 1000;
const double LOOP_INFO_VALUE = 50.0;
//#define DEPTH_PRIOR
//#define GT
#define UNIT_SPHERE_ERROR

extern double INIT_DEPTH;                           //值：5.0
extern double MIN_PARALLAX;                         //关键帧选择阈值，10.0/460
extern int ESTIMATE_EXTRINSIC;                      //IMU与相机外部参数，值：1（初步猜测外参，程序自动优化）

extern double ACC_N, ACC_W;                         //加速度测量噪声的标准差(0.2)，加速度bias标准差(2e-5)
extern double GYR_N, GYR_W;                         //陀螺仪测量噪声的标准差(0.02)，陀螺仪bias标准差(2e-5)

extern std::vector<Eigen::Matrix3d> RIC;            //初始R，四元数，相机->IMU [0, -1, 0 ; 1, 0, 0 ; 0, 0, 1]
extern std::vector<Eigen::Vector3d> TIC;            //初始t，相机->IMU [-0.02,-0.06, 0.01]
extern Eigen::Vector3d G;                           //重力，G.z()为重力大小（9.81007） gw

extern double BIAS_ACC_THRESHOLD;                   //值：0.1
extern double BIAS_GYR_THRESHOLD;                   //值：0.1
extern double SOLVER_TIME;                          //最大迭代求解时间（0.04ms），保证实时性
extern int NUM_ITERATIONS;                          //最大解算器数（8），保证实时性
extern std::string EX_CALIB_RESULT_PATH;            //外部校准结果输出文件：VINS文件夹/configeuroc/ex_calib_result.yaml
extern std::string VINS_RESULT_PATH;                //输出文件夹：VINS文件夹/config/euroc/vins_result.csv
extern std::string VINS_FOLDER_PATH;                //VINS主文件夹

extern int LOOP_CLOSURE;                            //是否开启回环检测及状态图优化（1）
extern int MIN_LOOP_NUM;                            //值：25
extern int MAX_KEYFRAME_NUM;                        //值：1000
extern std::string PATTERN_FILE;                    //回环模式文件所在路径 VINS文件夹/support_files/brief_pattern.yaml
extern std::string VOC_FILE;                        //回环词袋文件所在路径 VINS文件夹/support_files/brief_k10L6.bin
extern std::string CAM_NAMES;                       //配置文件路径？？
extern std::string IMAGE_TOPIC;                     //图像topic /cam0/image_row
extern std::string IMU_TOPIC;                       //IMUtopic /imu0

void readParameters(ros::NodeHandle &n);

enum SIZE_PARAMETERIZATION
{
    SIZE_POSE = 7,
    SIZE_SPEEDBIAS = 9,
    SIZE_FEATURE = 1,
    SIZE_POSE_SO3=6
};

enum StateOrder
{
    O_P = 0,
    O_R = 3,
    O_V = 6,
    O_BA = 9,
    O_BG = 12
};

enum NoiseOrder
{
    O_AN = 0,
    O_GN = 3,
    O_AW = 6,
    O_GW = 9
};
