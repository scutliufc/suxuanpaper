#pragma once

#include "parameters.h"
#include "feature_manager.h"
#include "utility/utility.h"
#include "utility/tic_toc.h"
#include "initial/solve_5pts.h"
#include "initial/initial_sfm.h"
#include "initial/initial_alignment.h"
#include "initial/initial_ex_rotation.h"
#include <std_msgs/Header.h>
#include <std_msgs/Float32.h>

#include <ceres/ceres.h>
#include "factor/imu_factor.h"
#include "factor/pose_local_parameterization.h"
#include "factor/projection_factor.h"
#include "factor/marginalization_factor.h"

#include <unordered_map>
#include <queue>
#include <opencv2/core/eigen.hpp>
#include "sophus/so3.h"
#include "sophus/se3.h"

using namespace Sophus;

struct RetriveData
{
    /* data */
    int old_index;
    int cur_index;
    double header;
    Vector3d P_old;
    Matrix3d R_old;
    vector<cv::Point2f> measurements;
    vector<int> features_ids; 
    bool relocalized;
    bool relative_pose;
    Vector3d relative_t;
    Quaterniond relative_q;
    double relative_yaw;
    double loop_pose[7];
    double loop_pose_so3[6];
};


/* 估计器类 */
class Estimator
{
  public:
    Estimator();

    void setParameter();                                   /* 设置参数，更新初始R和t，f_manager设置R */

    // interface
    void processIMU(double t, const Vector3d &linear_acceleration, const Vector3d &angular_velocity); //将measurement 的IMU部分进行了预积分处理
    void processImage(const map<int, vector<pair<int, Vector3d>>> &image, const std_msgs::Header &header);

    // internal
    void clearState();
    bool initialStructure();
    bool visualInitialAlign();
    bool relativePose(Matrix3d &relative_R, Vector3d &relative_T, int &l);
    void slideWindow();
    void solveOdometry();
    void slideWindowNew();
    void slideWindowOld();
    void optimization();
    void vector2double();
    void double2vector();
    bool failureDetection();


    enum SolverFlag
    {
        INITIAL,
        NON_LINEAR
    };

    enum MarginalizationFlag
    {
        MARGIN_OLD = 0,
        MARGIN_SECOND_NEW = 1
    };

    SolverFlag solver_flag;                               //求解器类型
    MarginalizationFlag  marginalization_flag;            //该帧是否为关键帧的标志，0为是，1为不是
    Vector3d g;                                            // 重力向量
    MatrixXd Ap[2], backup_A;
    VectorXd bp[2], backup_b;

    Matrix3d ric[NUM_OF_CAM];                              /* 初始旋转矩阵（参数输入） */
    Vector3d tic[NUM_OF_CAM];                              /* 初始平移矩阵（参数输入） */

    Vector3d Ps[(WINDOW_SIZE + 1)];                        //对应图像窗口的各帧的p
    Vector3d Vs[(WINDOW_SIZE + 1)];                        //对应图像窗口的各帧的v
    Matrix3d Rs[(WINDOW_SIZE + 1)];                        //对应图像窗口的各帧的Rwt
    Vector3d Bas[(WINDOW_SIZE + 1)];                       //对应图像窗口的各帧的a的bias
    Vector3d Bgs[(WINDOW_SIZE + 1)];                       //对应图像窗口的各帧的w的bias

    Matrix3d back_R0, last_R, last_R0;
    Vector3d back_P0, last_P, last_P0;
    std_msgs::Header Headers[(WINDOW_SIZE + 1)];

    IntegrationBase *pre_integrations[(WINDOW_SIZE + 1)];  //连续几帧图像帧的预积分
    Vector3d acc_0, gyr_0;                                 //最新IMU帧的a和w

    vector<double> dt_buf[(WINDOW_SIZE + 1)];
    vector<Vector3d> linear_acceleration_buf[(WINDOW_SIZE + 1)];
    vector<Vector3d> angular_velocity_buf[(WINDOW_SIZE + 1)];

    int frame_count;                                       //关键帧数
    int sum_of_outlier, sum_of_back, sum_of_front, sum_of_invalid;

    FeatureManager f_manager;
    MotionEstimator m_estimator;                          //运动估计器
    InitialEXRotation initial_ex_rotation;

    bool first_imu;                                        //是否是第一帧IMU的标记位，初始化为false，收到数据后变为true,clearState（）后变为false
    bool is_valid, is_key;
    bool failure_occur;

    vector<Vector3d> point_cloud;
    vector<Vector3d> margin_cloud;
    vector<Vector3d> key_poses;
    double initial_timestamp;                              //初始化时间戳，初始化时为0，第11帧时被赋值为图像帧的时间戳


    //double para_Pose[WINDOW_SIZE + 1][SIZE_POSE];
    double para_Pose_so3[WINDOW_SIZE + 1][SIZE_POSE_SO3];
    double para_SpeedBias[WINDOW_SIZE + 1][SIZE_SPEEDBIAS];
    double para_Feature[NUM_OF_F][SIZE_FEATURE];
    //double para_Ex_Pose[NUM_OF_CAM][SIZE_POSE];
    double para_Ex_Pose_so3[NUM_OF_CAM][SIZE_POSE_SO3];
    //double para_Retrive_Pose[SIZE_POSE];

    RetriveData retrive_pose_data, front_pose;
    vector<RetriveData> retrive_data_vector;
    int loop_window_index;
    bool relocalize;
    Vector3d relocalize_t;
    Matrix3d relocalize_r;

    MarginalizationInfo *last_marginalization_info;
    vector<double *> last_marginalization_parameter_blocks;

    map<double, ImageFrame> all_image_frame;               //储存所有的图像帧，时间戳（秒）+图像帧
    IntegrationBase *tmp_pre_integration;                  //图像的预积分类


    //void paraposeso3Toparapose();
    //void paraposeToparaposeso3();

};
