第四章程序在vins_mono基础上进行修改，基于ros操作系统

1.在ros的工作空间内进行catkin_make
2.运行 roslaunch vins_estimator euroc.launch开启程序
3.运行 在MH_05_difficult.bag 包所在位置运行 rosbag play MH_05_difficult.bag播放数据集数据即可
