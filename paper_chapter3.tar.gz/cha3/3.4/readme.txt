0.5文件夹： 论文3.4节 两两帧里程计
            进入build进行cmake ..和make操作
            进入bin文件夹运行  ./run_vo ../config/default.yaml
            结果会输出在result文件夹内，有result.txt(每一帧估计位姿)和time.txt(每一帧耗时)
            在result文件夹内，评测工具结果文件夹内为根据result.txt所估计的位姿轨迹和对应的groundtruth通过tum评测工具所得结果
                5tra.png为轨迹和真实轨迹对比图，5_and_ground.txt为轨迹和真值对齐后的输出,ate_verbose和rpe_verbose.txt分别为对应的ate和rpe输出完整结果

0.6文件夹： 论文3.4节 局部地图里程计
            进入build进行cmake ..和make操作
            进入bin文件夹运行  ./run_vo ../config/default.yaml
            结果会输出在result文件夹内，有result.txt(每一帧估计位姿)和time.txt(每一帧耗时)
            在result文件夹内，评测工具结果文件夹内为根据result.txt所估计的位姿轨迹和对应的groundtruth通过tum评测工具所得结果
                6tra.png为轨迹和真实轨迹对比图，6_and_ground.txt为轨迹和真值对齐后的输出,ate_verbose和rpe_verbose.txt分别为对应的ate和rpe输出完整结果

0.7文件夹： 论文3.4节 光流法里程计
            进入build进行cmake ..和make操作
            进入bin文件夹运行  ./run_vo ../config/default.yaml
            结果会输出在result文件夹内，有result.txt(每一帧估计位姿)和time.txt(每一帧耗时)
            在result文件夹内，评测工具结果文件夹内为根据result.txt所估计的位姿轨迹和对应的groundtruth通过tum评测工具所得结果
                7tra.png为轨迹和真实轨迹对比图，7_and_ground.txt为轨迹和真值对齐后的输出,ate_verbose和rpe_verbose.txt分别为对应的ate和rpe输出完整结果




