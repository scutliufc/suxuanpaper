#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <signal.h>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include<opencv2/flann/flann.hpp>
#include <Eigen/Core>
#include <Eigen/Dense>

#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main ( int argc, char** argv )
{
    if ( argc != 5 )
    {
        cout<<"usage: feature_extraction img1 img2 depth1 depth2"<<endl;
        return 1;
    }
    //-- 读取图像
    Mat img1 = imread ( argv[1], CV_LOAD_IMAGE_COLOR );
    Mat img2 = imread ( argv[2], CV_LOAD_IMAGE_COLOR );
    Mat depth1 = cv::imread ( argv[3],-1);
    Mat depth2 = cv::imread ( argv[4],-1);
    Mat img_1;
    Mat img_2;
    cvtColor(img1, img_1, COLOR_BGR2GRAY);
    cvtColor(img2, img_2, COLOR_BGR2GRAY);
//    img_1=img1;
//    img_2=img2;
    clock_t start, finish;
    double duration;
    Eigen::Matrix3d K;
    K<<615,0,320,0,615,240,0,0,1;
    Eigen::Matrix<double,3,4> T1;
    T1<<-1,0,0,0,0,1,0,0,0,0,1,0;
    Eigen::Matrix<double,3,4> T2;
    T2<< 0.997935473243181,0.00699460484875459,-0.0638425151910417,0.0428148317052006,
            0.000372980340112451,0.993403829295995,0.114667749719436,-0.0321694521256173,
            0.0642234546608519,-0.114454827085026,0.991350311659991,-0.278378683625368;
    //-- 初始化
    std::vector<KeyPoint> keypoints_1, keypoints_2;
    Mat descriptors_1, descriptors_2;
    Ptr<FeatureDetector> detector = ORB::create();
    Ptr<DescriptorExtractor> descriptor = ORB::create();

    //-- 第一步:检测 Oriented FAST 角点位置
    detector->detect ( img_1,keypoints_1 );
    detector->detect ( img_2,keypoints_2 );

    //-- 第二步:根据角点位置计算 BRIEF 描述子
    descriptor->compute ( img_1, keypoints_1, descriptors_1 );
    descriptor->compute ( img_2, keypoints_2, descriptors_2 );

    //实验1：BFmather.交叉
    {
        //-- 第三步:对两幅图像中的BRIEF描述子进行匹配，使用 Hamming 距离
        vector<DMatch> matches;
        BFMatcher matcher(NORM_HAMMING,true);
        //Ptr<DescriptorMatcher> matcher  = DescriptorMatcher::create ( "BruteForce-Hamming");
        start=clock();
        matcher.match ( descriptors_1, descriptors_2, matches );
        std::vector< DMatch > good_matches=matches;
        finish=clock();
        duration = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"实验1，bfmather+交叉耗时："<<duration<<"s"<<endl;

        //RANSAC内点：
        {
            // 分配空间
            int ptCount = (int)matches.size();
            Mat p1(ptCount, 2, CV_32F);
            Mat p2(ptCount, 2, CV_32F);

            // 把Keypoint转换为Mat
            Point2f pt;
            for (int i = 0; i<ptCount; i++)
            {
                pt = keypoints_1[matches[i].queryIdx].pt;
                p1.at<float>(i, 0) = pt.x;
                p1.at<float>(i, 1) = pt.y;

                pt = keypoints_2[matches[i].trainIdx].pt;
                p2.at<float>(i, 0) = pt.x;
                p2.at<float>(i, 1) = pt.y;
            }


            // 用RANSAC方法计算 基本矩阵F
            Mat m_Fundamental;
            vector<uchar> m_RANSACStatus;

            m_Fundamental = findFundamentalMat(p1, p2, m_RANSACStatus, FM_RANSAC);//?????????????????

            // 计算野点个数
            int OutlinerCount = 0;
            for (int i = 0; i<ptCount; i++)
            {
                if (m_RANSACStatus[i] == 0) // 状态为0表示野点
                {
                    OutlinerCount++;
                }
            }
            cout<<"实验1，bfmather+交叉：内点数量："<<ptCount - OutlinerCount<<endl;
            cout<<"实验1，bfmather+交叉：外点数量："<<OutlinerCount<<endl;
            cout<<"内点比例："<<double(ptCount - OutlinerCount)/double(ptCount)<<endl;
        }

        //-- 第五步:绘制匹配结果
        Mat img_goodmatch;
        drawMatches ( img1, keypoints_1, img2, keypoints_2, good_matches, img_goodmatch );
        imshow ( "实验1，bfmather+交叉：内点数量", img_goodmatch );
        imwrite("实验1，bfmather+交叉.jpg",img_goodmatch);
        waitKey(0);
    }

    //实验2：BFmather.knn
    {
        //-- 第三步:对两幅图像中的BRIEF描述子进行匹配，使用 Hamming 距离
        //-- Step 3: Matching descriptor vectors using FLANN matcher
        BFMatcher matcher(NORM_HAMMING);
        vector< DMatch > matches;
        vector<size_t> num;
        vector<vector<DMatch>> m_knnMatches;

        matches.clear();
        const float minRatio=1.f / 1.5f;
        start=clock();
        matcher.knnMatch(descriptors_1,descriptors_2,m_knnMatches,2);

        for (int i=0; i<m_knnMatches.size(); i++)
        {
            const DMatch& bestMatch=m_knnMatches[i][0];
            const DMatch& betterMatch=m_knnMatches[i][1];

            float distanceRatio=bestMatch.distance/betterMatch.distance;

            if (distanceRatio<minRatio)
            {
                matches.push_back(bestMatch);
            }
        }
        std::vector< DMatch > good_matches=matches;
        finish=clock();
        duration = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"实验2，bfmather+knn耗时："<<duration<<"s"<<endl;
        {
            // 分配空间
            int ptCount = (int)good_matches.size();
            Mat p1(ptCount, 2, CV_32F);
            Mat p2(ptCount, 2, CV_32F);

            // 把Keypoint转换为Mat
            Point2f pt;
            for (int i = 0; i<ptCount; i++)
            {
                pt = keypoints_1[good_matches[i].queryIdx].pt;
                p1.at<float>(i, 0) = pt.x;
                p1.at<float>(i, 1) = pt.y;

                pt = keypoints_2[good_matches[i].trainIdx].pt;
                p2.at<float>(i, 0) = pt.x;
                p2.at<float>(i, 1) = pt.y;
            }


            // 用RANSAC方法计算 基本矩阵F
            Mat m_Fundamental;
            vector<uchar> m_RANSACStatus;

            m_Fundamental = findFundamentalMat(p1, p2, m_RANSACStatus, FM_RANSAC);//?????????????????

            // 计算野点个数
            int OutlinerCount = 0;
            for (int i = 0; i<ptCount; i++)
            {
                if (m_RANSACStatus[i] == 0) // 状态为0表示野点
                {
                    OutlinerCount++;
                }
            }
            cout<<"实验2，bfmather+knn：内点数量："<<ptCount - OutlinerCount<<endl;
            cout<<"实验2，bfmather+knn：外点数量："<<OutlinerCount<<endl;
            cout<<"内点比例："<<double(ptCount - OutlinerCount)/double(ptCount)<<endl;
        }


        //-- 第五步:绘制匹配结果
        Mat img_goodmatch;
        drawMatches ( img1, keypoints_1, img2, keypoints_2, good_matches, img_goodmatch );
        imshow ( "实验2，bfmather+knn：内点数量", img_goodmatch );
        imwrite("实验2，bfmather+knn.jpg",img_goodmatch);
        waitKey(0);
    }

        //实验3：BFmather.短距离
    {
        //-- 第三步:对两幅图像中的BRIEF描述子进行匹配，使用 Hamming 距离
        //-- Step 3: Matching descriptor vectors using FLANN matcher
        vector<DMatch> matches;
    BFMatcher matcher ( NORM_HAMMING );
        start=clock();
    matcher.match ( descriptors_1, descriptors_2, matches );

    //-- 第四步:匹配点对筛选
    double min_dist=10000, max_dist=0;

    //找出所有匹配之间的最小距离和最大距离, 即是最相似的和最不相似的两组点之间的距离
    for ( int i = 0; i < descriptors_1.rows; i++ )
    {
        double dist = matches[i].distance;
        if ( dist < min_dist ) min_dist = dist;
        if ( dist > max_dist ) max_dist = dist;
    }

    // 仅供娱乐的写法
    min_dist = min_element( matches.begin(), matches.end(), [](const DMatch& m1, const DMatch& m2) {return m1.distance<m2.distance;} )->distance;
    max_dist = max_element( matches.begin(), matches.end(), [](const DMatch& m1, const DMatch& m2) {return m1.distance<m2.distance;} )->distance;

    //当描述子之间的距离大于两倍的最小距离时,即认为匹配有误.但有时候最小距离会非常小,设置一个经验值30作为下限.
    std::vector< DMatch > good_matches;
    for ( int i = 0; i < descriptors_1.rows; i++ )
    {
        if ( matches[i].distance <= max ( 2*min_dist, 30.0 ) )
        {
            good_matches.push_back ( matches[i] );
        }
    }
        finish=clock();
        duration = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"实验3，bfmather+radius耗时："<<duration<<"s"<<endl;
        {
            // 分配空间
            int ptCount = (int)good_matches.size();
            Mat p1(ptCount, 2, CV_32F);
            Mat p2(ptCount, 2, CV_32F);

            // 把Keypoint转换为Mat
            Point2f pt;
            for (int i = 0; i<ptCount; i++)
            {
                pt = keypoints_1[good_matches[i].queryIdx].pt;
                p1.at<float>(i, 0) = pt.x;
                p1.at<float>(i, 1) = pt.y;

                pt = keypoints_2[good_matches[i].trainIdx].pt;
                p2.at<float>(i, 0) = pt.x;
                p2.at<float>(i, 1) = pt.y;
            }


            // 用RANSAC方法计算 基本矩阵F
            Mat m_Fundamental;
            vector<uchar> m_RANSACStatus;

            m_Fundamental = findFundamentalMat(p1, p2, m_RANSACStatus, FM_RANSAC);//?????????????????

            // 计算野点个数
            int OutlinerCount = 0;
            for (int i = 0; i<ptCount; i++)
            {
                if (m_RANSACStatus[i] == 0) // 状态为0表示野点
                {
                    OutlinerCount++;
                }
            }
            cout<<"实验3，bfmather+radius：内点数量："<<ptCount - OutlinerCount<<endl;
            cout<<"实验3，bfmather+radius：外点数量："<<OutlinerCount<<endl;
            cout<<"内点比例："<<double(ptCount - OutlinerCount)/double(ptCount)<<endl;
        }
        //-- 第五步:绘制匹配结果
        Mat img_goodmatch;
        drawMatches ( img1, keypoints_1, img2, keypoints_2, good_matches, img_goodmatch );
        imshow ( "实验3，bfmather+radius", img_goodmatch );
        imwrite("实验3，bfmather+radius.jpg",img_goodmatch);
        waitKey(0);
    }

    //实验4：flann.交叉
    {
        //-- 第三步:对两幅图像中的BRIEF描述子进行匹配，使用 Hamming 距离
        vector<DMatch> matches;
        vector<DMatch> matches2;
        FlannBasedMatcher matcher(new flann::LshIndexParams(10, 10, 0),new flann::SearchParams());
        //Ptr<DescriptorMatcher> matcher  = DescriptorMatcher::create ( "BruteForce-Hamming");
        start=clock();
        matcher.match ( descriptors_1, descriptors_2, matches );
        matcher.match ( descriptors_2, descriptors_1, matches2);

        std::vector< DMatch > good_matches;
        for(size_t i=0;i<matches.size();i++)
        {
            int result=matches[i].trainIdx;
            if(i==matches2[result].trainIdx)
            {
                good_matches.push_back(matches[i]);
            }
        }
        finish=clock();
        duration = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"实验4，flann+交叉耗时："<<duration<<"s"<<endl;


        //RANSAC内点：
        {
            // 分配空间
            int ptCount = (int)good_matches.size();
            Mat p1(ptCount, 2, CV_32F);
            Mat p2(ptCount, 2, CV_32F);

            // 把Keypoint转换为Mat
            Point2f pt;
            for (int i = 0; i<ptCount; i++)
            {
                pt = keypoints_1[good_matches[i].queryIdx].pt;
                p1.at<float>(i, 0) = pt.x;
                p1.at<float>(i, 1) = pt.y;

                pt = keypoints_2[good_matches[i].trainIdx].pt;
                p2.at<float>(i, 0) = pt.x;
                p2.at<float>(i, 1) = pt.y;
            }


            // 用RANSAC方法计算 基本矩阵F
            Mat m_Fundamental;
            vector<uchar> m_RANSACStatus;

            m_Fundamental = findFundamentalMat(p1, p2, m_RANSACStatus, FM_RANSAC);//?????????????????

            // 计算野点个数
            int OutlinerCount = 0;
            for (int i = 0; i<ptCount; i++)
            {
                if (m_RANSACStatus[i] == 0) // 状态为0表示野点
                {
                    OutlinerCount++;
                }
            }
            cout<<"实验4，flann+交叉：内点数量："<<ptCount - OutlinerCount<<endl;
            cout<<"实验4，flann+交叉：外点数量："<<OutlinerCount<<endl;
            cout<<"内点比例："<<double(ptCount - OutlinerCount)/double(ptCount)<<endl;
        }

        //-- 第五步:绘制匹配结果
        Mat img_goodmatch;
        drawMatches ( img1, keypoints_1, img2, keypoints_2, good_matches, img_goodmatch );
        imshow ( "实验4，flann+交叉：内点数量", img_goodmatch );
        imwrite("实验4，flann+交叉.jpg",img_goodmatch);
        waitKey(0);
    }

    //实验5：flannmather.knn
    {
        //-- 第三步:对两幅图像中的BRIEF描述子进行匹配，使用 Hamming 距离
        //-- Step 3: Matching descriptor vectors using FLANN matcher
        FlannBasedMatcher matcher(new flann::LshIndexParams(10, 10, 0),new flann::SearchParams());
        vector< DMatch > matches;
        vector<vector<DMatch>> m_knnMatches;
        matches.clear();
        const float minRatio=1.f / 1.5f;
        start=clock();
        matcher.knnMatch(descriptors_1,descriptors_2,m_knnMatches,2);
        for (int i=0; i<m_knnMatches.size(); i++)
        {
            if(m_knnMatches[i].size()!=0)
            {
                const DMatch& bestMatch=m_knnMatches[i][0];
                const DMatch& betterMatch=m_knnMatches[i][1];
                float distanceRatio;
                if(betterMatch.distance!=0)
                    distanceRatio=bestMatch.distance/betterMatch.distance;
                else
                    distanceRatio=0;
                if (distanceRatio<minRatio)
                {
                    matches.push_back(bestMatch);
                }
            }

        }
        std::vector< DMatch > good_matches=matches;
        finish=clock();
        duration = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"实验5，flann+knn耗时："<<duration<<"s"<<endl;


        {
            // 分配空间
            int ptCount = (int)good_matches.size();
            Mat p1(ptCount, 2, CV_32F);
            Mat p2(ptCount, 2, CV_32F);

            // 把Keypoint转换为Mat
            Point2f pt;
            for (int i = 0; i<ptCount; i++)
            {
                pt = keypoints_1[good_matches[i].queryIdx].pt;
                p1.at<float>(i, 0) = pt.x;
                p1.at<float>(i, 1) = pt.y;

                pt = keypoints_2[good_matches[i].trainIdx].pt;
                p2.at<float>(i, 0) = pt.x;
                p2.at<float>(i, 1) = pt.y;
            }


            // 用RANSAC方法计算 基本矩阵F
            Mat m_Fundamental;
            vector<uchar> m_RANSACStatus;

            m_Fundamental = findFundamentalMat(p1, p2, m_RANSACStatus, FM_RANSAC);//?????????????????

            // 计算野点个数
            int OutlinerCount = 0;
            for (int i = 0; i<ptCount; i++)
            {
                if (m_RANSACStatus[i] == 0) // 状态为0表示野点
                {
                    OutlinerCount++;
                }
            }
            cout<<"实验5，flann+knn：内点数量："<<ptCount - OutlinerCount<<endl;
            cout<<"实验5，flann+knn：外点数量："<<OutlinerCount<<endl;
            cout<<"内点比例："<<double(ptCount - OutlinerCount)/double(ptCount)<<endl;
        }

        //-- 第五步:绘制匹配结果
        Mat img_goodmatch;
        drawMatches ( img1, keypoints_1, img2, keypoints_2, good_matches, img_goodmatch );
        imshow ( "实验5，flann+knn", img_goodmatch );
        imwrite("实验5，flann+knn.jpg",img_goodmatch);
        waitKey(0);
    }

    //实验6：flann.短距离
    {
        //-- 第三步:对两幅图像中的BRIEF描述子进行匹配，使用 Hamming 距离
        //-- Step 3: Matching descriptor vectors using FLANN matcher
        vector<DMatch> matches;
        FlannBasedMatcher matcher (new flann::LshIndexParams(10, 10, 0),new flann::SearchParams());
        start=clock();
        matcher.match ( descriptors_1, descriptors_2, matches );

        //-- 第四步:匹配点对筛选
        double min_dist=10000, max_dist=0;

        //找出所有匹配之间的最小距离和最大距离, 即是最相似的和最不相似的两组点之间的距离
        for ( int i = 0; i < descriptors_1.rows; i++ )
        {
            double dist = matches[i].distance;
            if ( dist < min_dist ) min_dist = dist;
            if ( dist > max_dist ) max_dist = dist;
        }

        // 仅供娱乐的写法
        min_dist = min_element( matches.begin(), matches.end(), [](const DMatch& m1, const DMatch& m2) {return m1.distance<m2.distance;} )->distance;
        max_dist = max_element( matches.begin(), matches.end(), [](const DMatch& m1, const DMatch& m2) {return m1.distance<m2.distance;} )->distance;

        //当描述子之间的距离大于两倍的最小距离时,即认为匹配有误.但有时候最小距离会非常小,设置一个经验值30作为下限.
        std::vector< DMatch > good_matches;
        for ( int i = 0; i < descriptors_1.rows; i++ )
        {
            if ( matches[i].distance <= max ( 2*min_dist, 30.0 ) )
            {
                good_matches.push_back ( matches[i] );
            }
        }
        finish=clock();
        duration = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"实验6，flann+radius耗时："<<duration<<"s"<<endl;
        {
            // 分配空间
            int ptCount = (int)good_matches.size();
            Mat p1(ptCount, 2, CV_32F);
            Mat p2(ptCount, 2, CV_32F);

            // 把Keypoint转换为Mat
            Point2f pt;
            for (int i = 0; i<ptCount; i++)
            {
                pt = keypoints_1[good_matches[i].queryIdx].pt;
                p1.at<float>(i, 0) = pt.x;
                p1.at<float>(i, 1) = pt.y;

                pt = keypoints_2[good_matches[i].trainIdx].pt;
                p2.at<float>(i, 0) = pt.x;
                p2.at<float>(i, 1) = pt.y;
            }


            // 用RANSAC方法计算 基本矩阵F
            Mat m_Fundamental;
            vector<uchar> m_RANSACStatus;

            m_Fundamental = findFundamentalMat(p1, p2, m_RANSACStatus, FM_RANSAC);//?????????????????

            // 计算野点个数
            int OutlinerCount = 0;
            for (int i = 0; i<ptCount; i++)
            {
                if (m_RANSACStatus[i] == 0) // 状态为0表示野点
                {
                    OutlinerCount++;
                }
            }
            cout<<"实验6，flann+radius：内点数量："<<ptCount - OutlinerCount<<endl;
            cout<<"实验6，flann+radius：外点数量："<<OutlinerCount<<endl;
            cout<<"内点比例："<<double(ptCount - OutlinerCount)/double(ptCount)<<endl;
        }
        //-- 第五步:绘制匹配结果
        Mat img_goodmatch;
        drawMatches ( img1, keypoints_1, img2, keypoints_2, good_matches, img_goodmatch );
        imshow ( "实验6，flann+radius", img_goodmatch );
        imwrite("实验6，flann+radius.jpg",img_goodmatch);
        waitKey(0);
    }

    return 0;
}