说明：
本文件夹为论文第3章3.2,3.3节实验程序及结果

各文件说明：

文件夹：
33matlab文件夹：内含3.3节实验结果的MATLAB画图程序
build文件夹：含编译文件（可删）
原始结果文件夹：含clion运行后保存的论文程序结果
cmake_modules文件夹：含所需的库find**.cmake文件
photo,tum,tum2,tumdesk:含所需使用的图片文件，一般采用photo文件夹即可

文件:

33.cpp: 
feature_extraction.cpp: 3.2.1节 sift/surf/orb三种方法，对四张图像的特征提取实验
         注：由于需要使用sift和surf特征，使用了opencv nofree.h，需要改为opencv2版本，在cmakelists.txt中本部分解开注释，
            并将其他部分注释掉（使用opencv3版本的)，方可使用
         在build文件夹内运行./feature_extraction ../photo/tsukuba_daylight_L_00001.png ../photo/muban.png ../photo/mohu.png ../photo/telangpu.png
my.cpp:  3.2.2节 六种特征匹配方法的实验 bf/flann+距离/knn/交叉
         在build文件夹内运行./my ../photo/1.png ../photo/2.png ../photo/1_depth.png ../photo/2_depth.png
323.cpp: 3.2.3节 两张图片的pnp运动估计
         在build文件夹内运行./pnp323 ../tumdesk/1305031453.359684.png ../tumdesk/1305031453.791716.png ../tumdesk/1305031453.374112.png
324.cpp: 3.2.4节 位姿优化
         在build文件夹内运行./pnp324 ../tum/1305031102.175304.png ../tum/1305031102.443271.png ../tum/1305031102.160407.png
33.cpp:  3.3节 光流法 特征法与光流法，不同特征数量，不同运动距离的比较
         在build文件夹内运行./lk33 ../tum/1305031102.175304.png ../tum/1305031103.343223.png ../tum/1305031102.160407.png
