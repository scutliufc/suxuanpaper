#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include <g2o/core/base_vertex.h>
#include <g2o/core/base_unary_edge.h>
#include <g2o/core/block_solver.h>
#include <g2o/core/optimization_algorithm_levenberg.h>
#include <g2o/solvers/csparse/linear_solver_csparse.h>
#include <g2o/types/sba/types_six_dof_expmap.h>
#include <chrono>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "sophus/so3.h"
#include "sophus/se3.h"

using namespace std;
using namespace cv;
using namespace Sophus;

void find_feature_matches (
        const Mat& img_1, const Mat& img_2,
        std::vector<KeyPoint>& keypoints_1,
        std::vector<KeyPoint>& keypoints_2,
        std::vector< DMatch >& matches,
        std::vector< DMatch >& matchesfour);
void bundleAdjustment (
        const vector<Point3f> points_3d,
        const vector<Point2f> points_2d,
        const Mat& K,
        Mat& R, Mat& t,SE3& resultse3
);

// 像素坐标转相机归一化坐标
Point2d pixel2cam ( const Point2d& p, const Mat& K );

int main ( int argc, char** argv )
{
    if ( argc != 4 )
    {
        cout<<"usage: pose_estimation_3d2d img1 img2 depth1"<<endl;
        return 1;
    }
    //-- 读取图像
    Mat img_1 = imread ( argv[1], 1 );
    Mat img_2 = imread ( argv[2], 1 );
    SE3 T1;

    Vector3d t1(1.3405,0.6266,1.6575);              //(实验1，xyz数据集)
    Quaterniond q(-0.3248,0.6574,0.6126,-0.2949);
    SO3 so31(q);
    T1=SE3(so31,t1);
    SE3 T2;

    //    1305031102.443271.png(0.0953763cm平移) 误差0.0096151,xyz:0.00484031 -0.00428924 -0.00711505 t:0.00125s
    Vector3d t2(1.2757,0.6256,1.5853);
    Quaterniond q2(-0.2890,0.6631,0.6278,-0.2876);

    //    1305031102.675285.png(0.208441cm平移) 误差0.0162142,xyz:0.016175 -0.000272719   0.00109266 t:0.000358s
//    Vector3d t2(1.2190,0.6245,1.5236);
//    Quaterniond q2(-0.2868,0.6665,0.6296,-0.2775);

    //    1305031102.911185.png(0.290047cm平移) 误差0.0238174,xyz:0.0229923 -0.00564511  0.00259903 t:0.000529s
//    Vector3d t2(1.1622,0.6244,1.4513);
//    Quaterniond q2(-0.2957,0.6675,0.6291,-0.2670);

    //    1305031103.343223.png(0.403165cm平移) 误差0.024773,xyz:0.0241586 0.00110685  0.0053702 t:0.000404s
//    Vector3d t2(1.1009,0.6229,1.3582);
//    Quaterniond q2(-0.2468,0.6777,0.6355,-0.2758);
    SO3 so32(q2);
    T2=SE3(so32,t2);

    clock_t start, finish;
    double duration;

    SE3 T3;
    Vector3d t3(0,0,0);
    Quaterniond q3(1,0,0,0);
    SO3 so33(q3);
    T3=SE3(so33,t3);

    vector<KeyPoint> keypoints_1, keypoints_2;
    vector<DMatch> matches;
    vector<DMatch> matchesfour;
    find_feature_matches ( img_1, img_2, keypoints_1, keypoints_2, matches,matchesfour);
    Mat img_goodmatch;
    drawMatches ( img_1, keypoints_1, img_2, keypoints_2, matches, img_goodmatch );
    imshow("1",img_goodmatch);
    imwrite("323exp1.jpg",img_goodmatch);
    waitKey(0);

    // 建立3D点
    Mat d1 = imread ( argv[3], CV_LOAD_IMAGE_UNCHANGED );       // 深度图为16位无符号数，单通道图像
    //Mat K = ( Mat_<double> ( 3,3 ) << 525.0, 0, 319.5, 0, 525.0, 239.5, 0, 0, 1 );
    Mat K = ( Mat_<double> ( 3,3 ) << 520.9, 0, 325.1, 0, 521.0, 249.7, 0, 0, 1 );
    vector<Point3f> pts_3d;
    vector<Point2f> pts_2d;
    for ( DMatch m:matches )
    {
        ushort d = d1.ptr<unsigned short> (int ( keypoints_1[m.queryIdx].pt.y )) [ int ( keypoints_1[m.queryIdx].pt.x ) ];
        if ( d == 0 )   // bad depth
            continue;
        float dd = d/5000.0 ;
        Point2d p1 = pixel2cam ( keypoints_1[m.queryIdx].pt, K );
        pts_3d.push_back ( Point3f ( p1.x*dd, p1.y*dd, dd ) );
        pts_2d.push_back ( keypoints_2[m.trainIdx].pt );
    }

    cout<<"3d-2d pairs: "<<pts_3d.size() <<endl;
    {
        start=clock();
        Mat r, t, inliers;
        solvePnPRansac(pts_3d, pts_2d, K, Mat(), r, t, false, 100, 4.0, 0.99, inliers,SOLVEPNP_EPNP); // 调用OpenCV 的 PnP 求解，可选择EPNP，DLS等方法
        Mat R;
        cv::Rodrigues ( r, R ); // r为旋转向量形式，用Rodrigues公式转换为矩阵
        finish=clock();
        duration = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"实验8，pnpransac,EPNP耗时："<<duration<<"s"<<endl;
        SE3 transform=SE3(
                SO3(r.at<double>(0,0), r.at<double>(1,0), r.at<double>(2,0)),
                Vector3d( t.at<double>(0,0), t.at<double>(1,0), t.at<double>(2,0))
        );
        SE3 estimate2=T1*transform.inverse();
        Vector3d error=T2.translation()-estimate2.translation();
        cout<<"平移量："<<Vector3d( t.at<double>(0,0), t.at<double>(1,0), t.at<double>(2,0)).transpose().norm()<<endl;
        cout<<"error:"<<error.transpose()<<" ";
        cout<<"error.norm:"<<error.norm()<<endl;
        SE3 youhuase3;
        start=clock();
        bundleAdjustment ( pts_3d, pts_2d, K, R, t ,youhuase3);
        finish=clock();
        duration = (double)(finish - start) / CLOCKS_PER_SEC;
        cout<<"实验8，位姿优化耗时："<<duration<<"s"<<endl;
        SE3 youhuahouestimate2=T1*youhuase3.inverse();
        Vector3d error2=T2.translation()-youhuahouestimate2.translation();
        cout<<"平移量："<<Vector3d( t.at<double>(0,0), t.at<double>(1,0), t.at<double>(2,0)).transpose().norm()<<endl;
        cout<<"error:"<<error2.transpose()<<" ";
        cout<<"error.norm:"<<error2.norm()<<endl;
    }
//    bundleAdjustment ( pts_3d, pts_2d, K, R, t );
}

void find_feature_matches ( const Mat& img_1, const Mat& img_2,
                            std::vector<KeyPoint>& keypoints_1,
                            std::vector<KeyPoint>& keypoints_2,
                            std::vector< DMatch >& matches,
                            std::vector< DMatch >& matchesfour
)
{
    //-- 初始化
    Mat descriptors_1, descriptors_2;
    Ptr<FeatureDetector> detector = ORB::create(500);
    Ptr<DescriptorExtractor> descriptor = ORB::create(500);
    //-- 第一步:检测 Oriented FAST 角点位置
    detector->detect ( img_1,keypoints_1 );
    detector->detect ( img_2,keypoints_2 );

    //-- 第二步:根据角点位置计算 BRIEF 描述子
    descriptor->compute ( img_1, keypoints_1, descriptors_1 );
    descriptor->compute ( img_2, keypoints_2, descriptors_2 );

    //-- 第三步:对两幅图像中的BRIEF描述子进行匹配，使用 Hamming 距离
    FlannBasedMatcher matcher (new flann::LshIndexParams(10, 10, 0),new flann::SearchParams());
    matcher.match ( descriptors_1, descriptors_2, matches );

    //-- 第四步:匹配点对筛选
    double min_dist=10000, max_dist=0;

    //找出所有匹配之间的最小距离和最大距离, 即是最相似的和最不相似的两组点之间的距离
    for ( int i = 0; i < descriptors_1.rows; i++ )
    {
        double dist = matches[i].distance;
        if ( dist < min_dist ) min_dist = dist;
        if ( dist > max_dist ) max_dist = dist;
    }

    // 仅供娱乐的写法
    min_dist = min_element( matches.begin(), matches.end(), [](const DMatch& m1, const DMatch& m2) {return m1.distance<m2.distance;} )->distance;
    max_dist = max_element( matches.begin(), matches.end(), [](const DMatch& m1, const DMatch& m2) {return m1.distance<m2.distance;} )->distance;

    //当描述子之间的距离大于两倍的最小距离时,即认为匹配有误.但有时候最小距离会非常小,设置一个经验值30作为下限.
    std::vector< DMatch > good_matches;
    for ( int i = 0; i < descriptors_1.rows; i++ )
    {
        if ( matches[i].distance <= max ( 2*min_dist, 30.0 ) )
        {
            if(matches[i].queryIdx>=0&&matches[i].queryIdx<matches.size())
            {
                good_matches.push_back ( matches[i] );
            }

        }
    }
    cout<<"good_mathes.size():"<<good_matches.size()<<endl;
    matches=good_matches;
}

Point2d pixel2cam ( const Point2d& p, const Mat& K )
{
    return Point2d
            (
                    ( p.x - K.at<double> ( 0,2 ) ) / K.at<double> ( 0,0 ),
                    ( p.y - K.at<double> ( 1,2 ) ) / K.at<double> ( 1,1 )
            );
}

void bundleAdjustment (
        const vector< Point3f > points_3d,
        const vector< Point2f > points_2d,
        const Mat& K,
        Mat& R, Mat& t,SE3& resultse3 )
{
    // 初始化g2o
    typedef g2o::BlockSolver< g2o::BlockSolverTraits<6,3> > Block;  // pose 维度为 6, landmark 维度为 3
    Block::LinearSolverType* linearSolver = new g2o::LinearSolverCSparse<Block::PoseMatrixType>(); // 线性方程求解器
    Block* solver_ptr = new Block ( linearSolver );     // 矩阵块求解器
    g2o::OptimizationAlgorithmLevenberg* solver = new g2o::OptimizationAlgorithmLevenberg ( solver_ptr );
    g2o::SparseOptimizer optimizer;
    optimizer.setAlgorithm ( solver );

    // vertex
    g2o::VertexSE3Expmap* pose = new g2o::VertexSE3Expmap(); // camera pose
    Eigen::Matrix3d R_mat;
    R_mat <<
          R.at<double> ( 0,0 ), R.at<double> ( 0,1 ), R.at<double> ( 0,2 ),
            R.at<double> ( 1,0 ), R.at<double> ( 1,1 ), R.at<double> ( 1,2 ),
            R.at<double> ( 2,0 ), R.at<double> ( 2,1 ), R.at<double> ( 2,2 );
    pose->setId ( 0 );
    pose->setEstimate ( g2o::SE3Quat (
            R_mat,
            Eigen::Vector3d ( t.at<double> ( 0,0 ), t.at<double> ( 1,0 ), t.at<double> ( 2,0 ) )
    ) );
    optimizer.addVertex ( pose );

    int index = 1;
    for ( const Point3f p:points_3d )   // landmarks
    {
        g2o::VertexSBAPointXYZ* point = new g2o::VertexSBAPointXYZ();
        point->setId ( index++ );
        point->setEstimate ( Eigen::Vector3d ( p.x, p.y, p.z ) );
        point->setMarginalized ( true ); // g2o 中必须设置 marg 参见第十讲内容
        optimizer.addVertex ( point );
    }

    // parameter: camera intrinsics
    g2o::CameraParameters* camera = new g2o::CameraParameters (
            K.at<double> ( 0,0 ), Eigen::Vector2d ( K.at<double> ( 0,2 ), K.at<double> ( 1,2 ) ), 0
    );
    camera->setId ( 0 );
    optimizer.addParameter ( camera );

    // edges
    index = 1;
    for ( const Point2f p:points_2d )
    {
        g2o::EdgeProjectXYZ2UV* edge = new g2o::EdgeProjectXYZ2UV();
        edge->setId ( index );
        edge->setVertex ( 0, dynamic_cast<g2o::VertexSBAPointXYZ*> ( optimizer.vertex ( index ) ) );
        edge->setVertex ( 1, pose );
        edge->setMeasurement ( Eigen::Vector2d ( p.x, p.y ) );
        edge->setParameterId ( 0,0 );
        edge->setInformation ( Eigen::Matrix2d::Identity() );
        optimizer.addEdge ( edge );
        index++;
    }

    chrono::steady_clock::time_point t1 = chrono::steady_clock::now();
    optimizer.setVerbose ( false );
    optimizer.initializeOptimization();
    optimizer.optimize ( 100 );
    chrono::steady_clock::time_point t2 = chrono::steady_clock::now();
    chrono::duration<double> time_used = chrono::duration_cast<chrono::duration<double>> ( t2-t1 );
    SE3 TT=SE3(
            SO3(Eigen::Isometry3d ( pose->estimate() ).linear()),
            Eigen::Isometry3d ( pose->estimate() ).translation()
    );
    resultse3=TT;
}