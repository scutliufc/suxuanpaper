#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/nonfree/nonfree.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "opencv2/nonfree/nonfree.hpp"
#include "opencv2/legacy/legacy.hpp"

using namespace std;
using namespace cv;

int main ( int argc, char** argv )
{
    if ( argc != 5 )
    {
        cout<<"usage: feature_extraction img1 img2 img3 img4"<<endl;
        return 1;
    }
    //-- 读取图像
    Mat img1 = imread ( argv[1], CV_LOAD_IMAGE_COLOR );
    Mat img2 = imread ( argv[2], CV_LOAD_IMAGE_COLOR );
    Mat img3 = imread ( argv[3], CV_LOAD_IMAGE_COLOR );
    Mat img4 = imread ( argv[4], CV_LOAD_IMAGE_COLOR );
    Mat img_1,img_2,img_3,img_4;
    cvtColor(img1, img_1, CV_RGB2GRAY);
    cvtColor(img2, img_2, CV_RGB2GRAY);
    cvtColor(img3, img_3, CV_RGB2GRAY);
    cvtColor(img4, img_4, CV_RGB2GRAY);

    clock_t start, finish;
    double duration;
    //提取特征点
    OrbFeatureDetector OrbDetector(500);
    vector<KeyPoint> keyPoint1, keyPoint2;
    SurfFeatureDetector surfDetector(500);
    vector<KeyPoint> keyPoint3, keyPoint4;
    SiftFeatureDetector siftDetector(500);
    vector<KeyPoint> keyPoint5, keyPoint6;


    start=clock();
    OrbDetector.detect(img_1, keyPoint1);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图1,orb耗时："<<duration<<"s"<<endl;


    start=clock();
    surfDetector.detect(img_1, keyPoint3);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图1,surf耗时："<<duration<<"s"<<endl;

    start=clock();
    siftDetector.detect(img_1, keyPoint5);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图1,sift耗时："<<duration<<"s"<<endl;


    start=clock();
    OrbDetector.detect(img_2, keyPoint2);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图2,orb耗时："<<duration<<"s"<<endl;

    start=clock();
    surfDetector.detect(img_2, keyPoint4);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图2,surf耗时："<<duration<<"s"<<endl;

    start=clock();
    siftDetector.detect(img_2, keyPoint6);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图2,sift耗时："<<duration<<"s"<<endl;




    Mat outimg1;
    drawKeypoints( img1, keyPoint1, outimg1, Scalar::all(-1), DrawMatchesFlags::DEFAULT );
    imshow("ORB特征点",outimg1);
    imwrite("ORBfigure1.jpg",outimg1);
    Mat outimg2;
    drawKeypoints( img2, keyPoint2, outimg2, Scalar::all(-1), DrawMatchesFlags::DEFAULT );

    Mat outimg3;
    drawKeypoints( img1, keyPoint3, outimg3, Scalar::all(-1), DrawMatchesFlags::DEFAULT );
    imshow("SURF特征点",outimg3);
    imwrite("SURFfigure1.jpg",outimg3);
    Mat outimg4;
    drawKeypoints( img2, keyPoint4, outimg4, Scalar::all(-1), DrawMatchesFlags::DEFAULT );

    Mat outimg5;
    drawKeypoints( img1, keyPoint5, outimg5, Scalar::all(-1), DrawMatchesFlags::DEFAULT );
    imshow("SIFT特征点",outimg5);
    imwrite("SIFTfigure1.jpg",outimg5);
    Mat outimg6;
    drawKeypoints( img2, keyPoint6, outimg6, Scalar::all(-1), DrawMatchesFlags::DEFAULT );

    waitKey(0);
    imshow("ORB特征点",outimg2);
    imwrite("ORBfigure2.jpg",outimg2);
    imshow("SURF特征点",outimg4);
    imwrite("SURFfigure2.jpg",outimg4);
    imshow("SIFT特征点",outimg6);
    imwrite("SIFTfigure2.jpg",outimg6);
    waitKey(0);


    vector<KeyPoint> keyPoint11, keyPoint22;
    vector<KeyPoint> keyPoint33, keyPoint44;
    vector<KeyPoint> keyPoint55, keyPoint66;


    start=clock();
    OrbDetector.detect(img_3, keyPoint11);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图3,orb耗时："<<duration<<"s"<<endl;

    start=clock();
    surfDetector.detect(img_3, keyPoint33);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图3,surf耗时："<<duration<<"s"<<endl;

    start=clock();
    siftDetector.detect(img_3, keyPoint55);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图3,sift耗时："<<duration<<"s"<<endl;

    start=clock();
    OrbDetector.detect(img_4, keyPoint22);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图4,orb耗时："<<duration<<"s"<<endl;

    start=clock();
    surfDetector.detect(img_4, keyPoint44);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图4,surf耗时："<<duration<<"s"<<endl;

    start=clock();
    siftDetector.detect(img_4, keyPoint66);
    finish=clock();
    duration = (double)(finish - start) / CLOCKS_PER_SEC;
    cout<<"图4,sift耗时："<<duration<<"s"<<endl;


    Mat outimg11;
    drawKeypoints( img3, keyPoint11, outimg11, Scalar::all(-1), DrawMatchesFlags::DEFAULT );
    imshow("ORB特征点",outimg11);
    imwrite("ORBfigure3.jpg",outimg11);
    Mat outimg22;
    drawKeypoints( img4, keyPoint22, outimg22, Scalar::all(-1), DrawMatchesFlags::DEFAULT );

    Mat outimg33;
    drawKeypoints( img3, keyPoint33, outimg33, Scalar::all(-1), DrawMatchesFlags::DEFAULT );
    imshow("SURF特征点",outimg33);
    imwrite("SURFfigure3.jpg",outimg33);
    Mat outimg44;
    drawKeypoints( img4, keyPoint44, outimg44, Scalar::all(-1), DrawMatchesFlags::DEFAULT );

    Mat outimg55;
    drawKeypoints( img3, keyPoint55, outimg55, Scalar::all(-1), DrawMatchesFlags::DEFAULT );
    imshow("SIFT特征点",outimg55);
    imwrite("SIFTfigure3.jpg",outimg55);
    Mat outimg66;
    drawKeypoints( img4, keyPoint66, outimg66, Scalar::all(-1), DrawMatchesFlags::DEFAULT );

    waitKey(0);
    imshow("ORB特征点",outimg22);
    imwrite("ORBfigure4.jpg",outimg22);
    imshow("SURF特征点",outimg44);
    imwrite("SURFfigure4.jpg",outimg44);
    imshow("SIFT特征点",outimg66);
    imwrite("SIFTfigure4.jpg",outimg66);
    waitKey(0);

    return 0;
}
